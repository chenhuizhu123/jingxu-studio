Jingxu Studio project package / 镜序项目包
Contains project records, assets and renders. API keys, approvals and jobs stay on the original device.
